"""
NILA-PMMVY FastAPI Backend
Tamil-first, voice-first AI assistant for PMMVY government scheme.

Architecture is intentionally modular: adding a new scheme or language
requires only:
  1. Adding a new knowledge base in data/<scheme>.py
  2. Adding a new route or scheme_id parameter in this file.
"""

import os
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel
from dotenv import load_dotenv
import google.generativeai as genai

from data.pmmvy import PMMVY_KNOWLEDGE_BASE, get_scheme_summary, get_context_for_ai

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("nila")

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = "gemini-1.5-flash"  # fast, capable, free-tier friendly


# ---------------------------------------------------------------------------
# System prompt – strict guardrails
# ---------------------------------------------------------------------------
def build_system_prompt() -> str:
    context = get_context_for_ai()
    return f"""
நீ NILA – ஒரு பயனுள்ள, நம்பகமான, அன்பான தமிழ் AI உதவியாளர்.
நீ பிரதான் மந்திரி மாத்ரு வந்தனா யோஜனா (PMMVY) திட்டம் பற்றி மட்டுமே பதில் சொல்வாய்.

உன்னுடைய முக்கியமான விதிகள்:
1. எப்போதும் எளிய, தெளிவான தமிழில் பதில் சொல்.
2. கீழே கொடுக்கப்பட்ட அதிகாரப்பூர்வ PMMVY தகவலை மட்டுமே பயன்படுத்து. புதிய தகவல்களை கற்பனையாக உருவாக்காதே.
3. ஒருவரின் தகுதியை நீயே முடிவு செய்யாதே. "அரசு அதிகாரப்பூர்வ செயல்முறை மட்டுமே தகுதியை முடிவு செய்யும்" என்று தெளிவாக சொல்.
4. Aadhaar எண், OTP, PIN, கடவுச்சொல், வங்கி தகவல் எதுவும் கேட்காதே, ஒருபோதும்.
5. PMMVY அல்லாத வேறு திட்டங்களைப் பற்றி கேட்டால், "இப்போது PMMVY திட்டம் மட்டுமே ஆதரிக்கப்படுகிறது" என்று சொல்.
6. எப்போதும் அதிகாரப்பூர்வ இணையதளம் https://pmmvy.wcd.gov.in அல்லது அருகிலுள்ள அங்கன்வாடி மையம் செல்லுமாறு அறிவுறுத்து.
7. பதில்கள் சுருக்கமாகவும் புரிதலாகவும் இருக்க வேண்டும் – 3 முதல் 6 வாக்கியங்கள் மட்டுமே.
8. பயனர் கேட்கும் மொழி தமிழ் அல்லாவிட்டாலும், தமிழிலேயே பதில் சொல்.

{context}
"""


# ---------------------------------------------------------------------------
# Gemini client initialisation
# ---------------------------------------------------------------------------
model: genai.GenerativeModel | None = None
chat_sessions: dict[str, genai.ChatSession] = {}


@asynccontextmanager
async def lifespan(app: FastAPI):
    global model
    if not GEMINI_API_KEY:
        logger.warning("GEMINI_API_KEY not set. Chat endpoint will return mock responses.")
    else:
        genai.configure(api_key=GEMINI_API_KEY)
        model = genai.GenerativeModel(
            model_name=GEMINI_MODEL,
            system_instruction=build_system_prompt(),
            generation_config=genai.types.GenerationConfig(
                temperature=0.3,      # low temperature = factual, consistent
                top_p=0.9,
                max_output_tokens=512,
            ),
        )
        logger.info("Gemini model initialised: %s", GEMINI_MODEL)
    yield
    chat_sessions.clear()


# ---------------------------------------------------------------------------
# FastAPI app
# ---------------------------------------------------------------------------
app = FastAPI(
    title="NILA-PMMVY API",
    description="Tamil-first AI assistant for PMMVY government scheme",
    version="1.0.0",
    lifespan=lifespan,
)

# Serve static files
app.mount("/static", StaticFiles(directory="static"), name="static")


# ---------------------------------------------------------------------------
# Request / Response schemas
# ---------------------------------------------------------------------------
class ChatRequest(BaseModel):
    message: str
    session_id: str = "default"


class ChatResponse(BaseModel):
    reply: str
    session_id: str
    scheme: str = "PMMVY"


# ---------------------------------------------------------------------------
# Fallback Tamil responses (no API key / Gemini unavailable)
#
# Structure: ordered list of (frozenset_of_keywords, response_string).
# The FIRST rule whose ANY keyword matches the message wins.
# Rules are ordered from MOST SPECIFIC to LEAST SPECIFIC so that
# benefit/money questions are caught before the generic "திட்டம்" rule.
# ---------------------------------------------------------------------------

BENEFIT_RESPONSE = (
    "PMMVY திட்டத்தின் கீழ் முதல் குழந்தைக்கு மொத்தம் ₹5,000 வழங்கப்படுகிறது.\n\n"
    "• முதல் தவணை: ₹3,000\n"
    "• இரண்டாவது தவணை: ₹2,000\n\n"
    "இந்த தொகை திட்டத்தின் விதிமுறைகள் மற்றும் தேவையான நிபந்தனைகள் பூர்த்தி செய்யப்பட்ட "
    "பிறகு வழங்கப்படும்.\n\n"
    "இரண்டாவது குழந்தை பெண் குழந்தையாக இருந்தால், தகுதியுடையவர்களுக்கு ₹6,000 "
    "ஒரு தவணையாக வழங்கப்படுகிறது.\n\n"
    "இது தகவல்/முன்கூட்டிய வழிகாட்டல் மட்டுமே; இறுதி தகுதி மற்றும் ஒப்புதல் "
    "அரசு அதிகாரிகளால் தீர்மானிக்கப்படும்."
)

# Each tuple: (set_of_trigger_keywords, tamil_response)
# Evaluated in order — first match wins.
FALLBACK_RULES: list[tuple[frozenset, str]] = [
    # --- BENEFIT / MONEY (most specific — must come BEFORE scheme rule) ---
    (
        frozenset([
            # Tamil keywords
            "எவ்வளவு பணம்", "எவ்வளவு", "பணம் கிடைக்கும்", "பணம் கிடைக்குமா",
            "முதல் குழந்தைக்கு", "முதல் குழந்தை பணம்",
            "எத்தனை பணம்", "எந்த பணம்", "தொகை", "நிதி",
            "₹5000", "₹5,000", "5000", "6000", "₹6000", "₹6,000",
            "தவணை", "installment",
            # English keywords
            "how much", "money", "amount", "benefit", "cash",
            "first child", "payment",
        ]),
        BENEFIT_RESPONSE,
    ),
    # --- ELIGIBILITY ---
    (
        frozenset([
            "தகுதி", "தகுதியான", "தகுதியானவரா", "யாருக்கு",
            "eligible", "eligibility", "qualify",
        ]),
        (
            "இந்தத் திட்டம் குடும்பத்தின் முதல் குழந்தையைப் பெற்றெடுக்கும் 19 வயது மேல் உள்ள "
            "கர்ப்பிணிப் பெண்களுக்கு உரியது. "
            "அமைப்பு சாராத் தொழிலாளர்கள், விவசாயிகள், வீட்டு வேலையாட்கள் தகுதி உடையவர்கள். "
            "இறுதி தகுதியை அரசு அதிகாரப்பூர்வ செயல்முறை மட்டுமே தீர்மானிக்கும். "
            "அருகிலுள்ள அங்கன்வாடி மையம் செல்லவும்."
        ),
    ),
    # --- DOCUMENTS ---
    (
        frozenset([
            "ஆவணம்", "ஆவணங்கள்", "documents", "papers", "certificate",
            "MCP", "பாஸ்புக்", "passbook",
        ]),
        (
            "தேவையான ஆவணங்கள்: MCP கார்டு, ஆதார் அட்டை (பயனர் மற்றும் கணவர்), "
            "வங்கி பாஸ்புக், குழந்தை பிறப்பு சான்றிதழ் (3வது தவணைக்கு), "
            "குழந்தையின் தடுப்பூசி அட்டை (3வது தவணைக்கு). "
            "அருகிலுள்ள அங்கன்வாடி மையத்தில் விண்ணப்பிக்கலாம்."
        ),
    ),
    # --- APPLICATION PROCESS ---
    (
        frozenset([
            "விண்ணப்ப", "விண்ணப்பிப்பது", "விண்ணப்பிக்க", "எப்படி",
            "apply", "application", "register", "பதிவு",
        ]),
        (
            "விண்ணப்பிக்க: 1) அருகிலுள்ள அங்கன்வாடி மையம் செல்லுங்கள். "
            "2) கர்ப்பத்தை பதிவு செய்யுங்கள், MCP கார்டு பெறுங்கள். "
            "3) படிவம் 1A, 1B, 1C நிரப்பி ஆவணங்களுடன் சமர்ப்பிக்கவும். "
            "4) https://pmmvy.wcd.gov.in இல் ஆன்லைனிலும் விண்ணப்பிக்கலாம். "
            "உதவி எண்: 1800-111-555"
        ),
    ),
    # --- GENERAL SCHEME INFO (least specific — catch-all for scheme questions) ---
    (
        frozenset([
            "திட்டம்", "PMMVY", "pmmvy", "என்ன", "what is",
            "scheme", "யோஜனா", "vandana",
        ]),
        (
            "பிரதான் மந்திரி மாத்ரு வந்தனா யோஜனா (PMMVY) திட்டம் கர்ப்பிணி பெண்களுக்கும் "
            "தாய்ப்பால் கொடுக்கும் தாய்மார்களுக்கும் நிதி உதவி வழங்கும் மத்திய அரசு திட்டம். "
            "முதல் குழந்தைக்கு ₹5,000 இரண்டு தவணைகளில் நேரடியாக வங்கி கணக்கில் வழங்கப்படும். "
            "அதிகாரப்பூர்வ இணையதளம்: https://pmmvy.wcd.gov.in"
        ),
    ),
]

DEFAULT_FALLBACK = (
    "நான் NILA. PMMVY திட்டம் பற்றிய கேள்விகளுக்கு பதில் சொல்வேன். "
    "முழு விவரங்களுக்கு அருகிலுள்ள அங்கன்வாடி மையம் செல்லவும் அல்லது "
    "https://pmmvy.wcd.gov.in பார்க்கவும். உதவி எண்: 1800-111-555"
)


def get_fallback_response(message: str) -> str:
    """
    Match the user message against FALLBACK_RULES in priority order.
    Each rule's keyword set is checked for ANY substring match against the
    lowercased message. Returns the first matching response, or DEFAULT_FALLBACK.
    """
    msg_lower = message.lower()
    for keywords, response in FALLBACK_RULES:
        if any(kw.lower() in msg_lower for kw in keywords):
            return response
    return DEFAULT_FALLBACK


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.get("/")
async def serve_index():
    return FileResponse("static/index.html")


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "service": "NILA-PMMVY",
        "ai_ready": model is not None,
        "version": "1.0.0",
    }


@app.get("/api/scheme")
async def get_scheme():
    """Return structured PMMVY scheme information."""
    return JSONResponse(content=get_scheme_summary())


@app.post("/api/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    user_message = request.message.strip()
    if not user_message:
        raise HTTPException(status_code=400, detail="Message cannot be empty")

    if not model:
        # No API key – use keyword fallback
        reply = get_fallback_response(user_message)
        return ChatResponse(reply=reply, session_id=request.session_id)

    # Reuse chat session per session_id for conversational context
    if request.session_id not in chat_sessions:
        chat_sessions[request.session_id] = model.start_chat(history=[])

    session = chat_sessions[request.session_id]

    try:
        response = session.send_message(user_message)
        reply = response.text.strip()
    except Exception as exc:
        logger.error("Gemini error: %s", exc)
        reply = get_fallback_response(user_message)

    return ChatResponse(reply=reply, session_id=request.session_id)
