"""
NILA-PMMVY: Controlled PMMVY Knowledge Base
Source: Ministry of Women and Child Development, Government of India
Official Portal: https://pmmvy.wcd.gov.in
"""

PMMVY_KNOWLEDGE_BASE = {
    "scheme_name": "Pradhan Mantri Matru Vandana Yojana (PMMVY)",
    "tamil_name": "பிரதான் மந்திரி மாத்ரு வந்தனா யோஜனா (PMMVY)",
    "ministry": "Ministry of Women and Child Development, Government of India",
    "official_portal": "https://pmmvy.wcd.gov.in",
    "official_source": "https://wcd.nic.in/schemes/pradhan-mantri-matru-vandana-yojana",

    "purpose": (
        "PMMVY is a centrally-sponsored conditional cash transfer scheme "
        "implemented by the Ministry of Women and Child Development, Government of India. "
        "It provides partial wage compensation to pregnant women and lactating mothers "
        "for the first child in the family, encouraging adequate rest and proper nutrition "
        "before and after delivery. The scheme was launched in January 2017 under the "
        "National Food Security Act, 2013."
    ),

    "benefits": {
        "first_child": {
            "total_amount": "Rs. 5,000",
            "description": "For the first living child born in the family",
            "installments": [
                {
                    "installment": "1st",
                    "amount": "Rs. 1,000",
                    "condition": "On registration of pregnancy at the Anganwadi Centre (AWC) / approved Health facility",
                },
                {
                    "installment": "2nd",
                    "amount": "Rs. 2,000",
                    "condition": "After receiving at least one Ante-Natal Check-up (ANC), not before 6 months of pregnancy",
                },
                {
                    "installment": "3rd",
                    "amount": "Rs. 2,000",
                    "condition": "After child is born and registered, child has received BCG, OPV, DPT and Hepatitis-B first cycle of vaccinations",
                },
            ],
        },
        "second_child_girl": {
            "total_amount": "Rs. 6,000",
            "description": "A one-time payment for the second child if she is a girl (PMMVY 2.0 provision)",
            "note": "This provision aims to encourage the birth of girl children and fight gender bias.",
        },
        "payment_mode": "Direct Benefit Transfer (DBT) directly into the beneficiary's bank account linked with Aadhaar",
    },

    "eligibility": {
        "general": [
            "All pregnant women and lactating mothers who are citizens of India",
            "Pregnant women and lactating mothers who are employed in regular employment with the Central Government or State Governments or Public Sector Undertakings or those who are in receipt of similar benefits under any law for the time being in force are NOT eligible",
            "The benefit is for the first living child of the family",
            "Pregnant women aged 19 years and above",
        ],
        "categories_eligible": [
            "Women working in the informal/unorganised sector",
            "Women farmers",
            "Daily wage workers",
            "Domestic workers",
            "Women who are not covered under any formal maternity benefit scheme",
        ],
        "note": (
            "Final eligibility is determined by the concerned Anganwadi Worker, "
            "the Anganwadi Centre, or the approved health facility as per official government guidelines. "
            "NILA is an information assistant only and does NOT determine your eligibility."
        ),
    },

    "documents_required": [
        "MCP (Mother and Child Protection) Card",
        "Identity proof: Aadhaar card of the beneficiary",
        "Identity proof: Aadhaar card of the husband/father (if applicable)",
        "Bank passbook or bank account details of the beneficiary",
        "Proof of pregnancy / delivery: as required by the Anganwadi Centre or health facility",
        "Child's birth certificate (for 3rd installment)",
        "Vaccination card of the child showing BCG, OPV, DPT, and Hepatitis-B vaccinations (for 3rd installment)",
    ],

    "application_process": [
        "Step 1: Visit your nearest Anganwadi Centre (AWC) or approved health facility as soon as you become pregnant.",
        "Step 2: Register your pregnancy at the AWC or health facility and get the MCP (Mother and Child Protection) card.",
        "Step 3: Collect the PMMVY application form (Form 1A for 1st installment, Form 1B for 2nd installment, Form 1C for 3rd installment) from the AWC or health facility OR apply online at https://pmmvy.wcd.gov.in",
        "Step 4: Fill the form with required details and submit it along with supporting documents to the AWC or health facility.",
        "Step 5: Ensure your bank account is linked with your Aadhaar for Direct Benefit Transfer (DBT).",
        "Step 6: After verification, the installment amount will be transferred directly to your bank account.",
        "You can also apply online at the official PMMVY portal: https://pmmvy.wcd.gov.in",
    ],

    "where_to_apply": [
        "Nearest Anganwadi Centre (AWC)",
        "Government health facilities / PHC (Primary Health Centre)",
        "Online portal: https://pmmvy.wcd.gov.in",
        "Common Service Centres (CSC)",
    ],

    "helpline": "1800-111-555 (Toll-free PMMVY helpline)",

    "key_dates": {
        "scheme_launch": "January 1, 2017",
        "current_version": "PMMVY 2.0 (revised guidelines from 2022 onwards)",
    },

    "sdg_alignment": {
        "SDG 5": "Gender Equality – Supports women's health and reduces gender discrimination",
        "SDG 4": "Quality Education – Encourages awareness of maternal and child health",
        "SDG 10": "Reduced Inequalities – Provides financial support to women in the unorganised sector",
    },

    "safety_note": (
        "NILA is an information-only assistant. "
        "NEVER share your Aadhaar number, OTP, PIN, password, or bank credentials with anyone in this chat or elsewhere. "
        "Official government staff will NEVER ask for these details over chat, phone, or SMS. "
        "Always apply only through official channels: https://pmmvy.wcd.gov.in or your nearest Anganwadi Centre."
    ),
}


def get_scheme_summary() -> dict:
    """Return a clean summary suitable for API responses."""
    kb = PMMVY_KNOWLEDGE_BASE
    return {
        "scheme_name": kb["scheme_name"],
        "tamil_name": kb["tamil_name"],
        "official_portal": kb["official_portal"],
        "benefits": kb["benefits"],
        "eligibility_note": kb["eligibility"]["note"],
        "helpline": kb["helpline"],
    }


def get_context_for_ai() -> str:
    """
    Build a concise, structured context string to pass to the AI model.
    This ensures the AI answers ONLY from verified PMMVY information.
    """
    kb = PMMVY_KNOWLEDGE_BASE
    installments = kb["benefits"]["first_child"]["installments"]
    inst_text = "\n".join(
        f"  - {i['installment']} தவணை: {i['amount']} – {i['condition']}"
        for i in installments
    )
    docs = "\n".join(f"  - {d}" for d in kb["documents_required"])
    steps = "\n".join(f"  {s}" for s in kb["application_process"])
    eligibility = "\n".join(f"  - {e}" for e in kb["eligibility"]["general"])
    categories = "\n".join(f"  - {c}" for c in kb["eligibility"]["categories_eligible"])

    return f"""
=== PMMVY அதிகாரப்பூர்வ தகவல் (VERIFIED OFFICIAL INFORMATION) ===
திட்டம்: {kb['scheme_name']}
அமைச்சகம்: {kb['ministry']}
அதிகாரப்பூர்வ இணையதளம்: {kb['official_portal']}
உதவி எண்: {kb['helpline']}

திட்டத்தின் நோக்கம்:
{kb['purpose']}

நலன்கள் (BENEFITS):
முதல் குழந்தை: {kb['benefits']['first_child']['total_amount']} மூன்று தவணைகளில்:
{inst_text}

இரண்டாவது குழந்தை பெண்ணாக இருந்தால்: {kb['benefits']['second_child_girl']['total_amount']} ஒரே தவணையில்.
பணம் செலுத்தும் முறை: {kb['benefits']['payment_mode']}

தகுதி (ELIGIBILITY):
{eligibility}
தகுதி உடைய தொழிலாளர் வகைகள்:
{categories}

தேவையான ஆவணங்கள் (DOCUMENTS):
{docs}

விண்ணப்பிக்கும் முறை (APPLICATION PROCESS):
{steps}

விண்ணப்பிக்கும் இடங்கள்: {', '.join(kb['where_to_apply'])}

முக்கியமான குறிப்பு: {kb['eligibility']['note']}
பாதுகாப்பு குறிப்பு: {kb['safety_note']}
=== END OF OFFICIAL INFORMATION ===
"""
