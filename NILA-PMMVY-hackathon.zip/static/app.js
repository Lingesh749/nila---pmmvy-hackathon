/**
 * NILA-PMMVY | app.js
 * Tamil-first, voice-first AI assistant for PMMVY.
 *
 * Features:
 *  - Browser Speech Recognition (ta-IN)
 *  - Browser Speech Synthesis (ta-IN)
 *  - Chat with FastAPI /api/chat
 *  - Quick question buttons
 *  - Speak-back each NILA reply
 *  - Graceful degradation if mic/TTS unavailable
 */

/* =========================================================
   State
   ========================================================= */
const state = {
  sessionId: 'session_' + Math.random().toString(36).slice(2, 10),
  isListening: false,
  isSending: false,
  recognition: null,
  ttsVoice: null,
};

/* =========================================================
   DOM References
   ========================================================= */
const chatArea   = document.getElementById('chatArea');
const textInput  = document.getElementById('textInput');
const sendBtn    = document.getElementById('sendBtn');
const micBtn     = document.getElementById('micBtn');
const micLabel   = document.getElementById('micLabel');
const statusBar  = document.getElementById('statusBar');
const welcomeCard = document.getElementById('welcomeCard');

/* =========================================================
   Speech Synthesis (TTS) – Tamil ta-IN
   ========================================================= */
function initTTS() {
  if (!window.speechSynthesis) return;

  function pickVoice() {
    const voices = window.speechSynthesis.getVoices();
    // Prefer Tamil (ta-IN), fall back to any Tamil, then any available
    state.ttsVoice =
      voices.find(v => v.lang === 'ta-IN') ||
      voices.find(v => v.lang.startsWith('ta')) ||
      voices[0] || null;
  }

  pickVoice();
  window.speechSynthesis.onvoiceschanged = pickVoice;
}

function speak(text) {
  if (!window.speechSynthesis) return;
  window.speechSynthesis.cancel(); // stop any ongoing speech
  const utter = new SpeechSynthesisUtterance(text);
  utter.lang = 'ta-IN';
  utter.rate = 0.9;
  utter.pitch = 1.05;
  if (state.ttsVoice) utter.voice = state.ttsVoice;
  window.speechSynthesis.speak(utter);
}

/* =========================================================
   Speech Recognition (STT) – Tamil ta-IN
   ========================================================= */
function initSpeechRecognition() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) {
    micBtn.disabled = true;
    micBtn.title = 'இந்த உலாவியில் குரல் அங்கீகாரம் ஆதரிக்கப்படவில்லை';
    micLabel.textContent = 'குரல் ஆதரிக்கப்படவில்லை';
    setStatus('உங்கள் உலாவியில் மைக் இல்லை. தட்டச்சு பயன்படுத்தவும்.', 'error');
    return;
  }

  const rec = new SR();
  rec.lang = 'ta-IN';
  rec.continuous = false;
  rec.interimResults = true;
  rec.maxAlternatives = 1;

  rec.onstart = () => {
    state.isListening = true;
    micBtn.classList.add('listening');
    micBtn.innerHTML = '⏹️';
    micLabel.textContent = 'கேட்கிறேன்… பேசவும்';
    setStatus('கேட்கிறேன்…', 'active');
  };

  rec.onresult = (event) => {
    let transcript = '';
    for (let i = event.resultIndex; i < event.results.length; i++) {
      transcript += event.results[i][0].transcript;
    }
    textInput.value = transcript;

    if (event.results[event.results.length - 1].isFinal) {
      stopListening();
      if (transcript.trim()) sendMessage();
    }
  };

  rec.onerror = (event) => {
    stopListening();
    const errMap = {
      'not-allowed': 'மைக் அனுமதி மறுக்கப்பட்டது. உலாவி அமைப்புகளை சரிபார்க்கவும்.',
      'no-speech': 'பேச்சு கேட்கவில்லை. மீண்டும் முயற்சிக்கவும்.',
      'network': 'நெட்வொர்க் பிழை. இணைப்பை சரிபார்க்கவும்.',
    };
    setStatus(errMap[event.error] || 'மைக் பிழை: ' + event.error, 'error');
  };

  rec.onend = () => {
    if (state.isListening) stopListening();
  };

  state.recognition = rec;
}

function toggleMic() {
  if (!state.recognition) {
    setStatus('மைக் இந்த உலாவியில் ஆதரிக்கப்படவில்லை.', 'error');
    return;
  }
  if (state.isListening) {
    state.recognition.stop();
    stopListening();
  } else {
    try {
      state.recognition.start();
    } catch (e) {
      setStatus('மைக் தொடங்க இயலவில்லை: ' + e.message, 'error');
    }
  }
}

function stopListening() {
  state.isListening = false;
  micBtn.classList.remove('listening');
  micBtn.innerHTML = '🎙️';
  micLabel.textContent = 'தமிழில் பேசவும்';
  setStatus('');
}

/* =========================================================
   Chat – UI Helpers
   ========================================================= */
function setStatus(msg, type = '') {
  statusBar.textContent = msg;
  statusBar.className = 'status-bar' + (type ? ' ' + type : '');
}

function hideWelcomeCard() {
  if (welcomeCard) {
    welcomeCard.style.display = 'none';
  }
}

function appendMessage(role, text) {
  hideWelcomeCard();
  const wrapper = document.createElement('div');
  wrapper.className = 'message ' + role;

  const avatar = document.createElement('div');
  avatar.className = 'avatar';
  avatar.textContent = role === 'nila' ? '🌙' : '👤';
  avatar.setAttribute('aria-hidden', 'true');

  const bubble = document.createElement('div');
  bubble.className = 'bubble';
  bubble.textContent = text;

  // Add speak button for NILA messages
  if (role === 'nila') {
    const speakRow = document.createElement('div');
    const speakBtnEl = document.createElement('button');
    speakBtnEl.className = 'speak-btn';
    speakBtnEl.innerHTML = '🔊 கேக்க';
    speakBtnEl.setAttribute('aria-label', 'இந்த பதிலை கேக்க');
    speakBtnEl.onclick = () => speak(text);
    speakRow.appendChild(speakBtnEl);

    const messageContent = document.createElement('div');
    messageContent.appendChild(bubble);
    messageContent.appendChild(speakRow);

    wrapper.appendChild(avatar);
    wrapper.appendChild(messageContent);
  } else {
    wrapper.appendChild(avatar);
    wrapper.appendChild(bubble);
  }

  chatArea.appendChild(wrapper);
  chatArea.scrollTop = chatArea.scrollHeight;
  return wrapper;
}

function showTyping() {
  const wrapper = document.createElement('div');
  wrapper.className = 'message nila';
  wrapper.id = 'typingIndicator';

  const avatar = document.createElement('div');
  avatar.className = 'avatar';
  avatar.textContent = '🌙';
  avatar.setAttribute('aria-hidden', 'true');

  const indicator = document.createElement('div');
  indicator.className = 'typing-indicator';
  indicator.setAttribute('aria-label', 'NILA பதில் தயாரிக்கிறது');
  for (let i = 0; i < 3; i++) {
    const dot = document.createElement('div');
    dot.className = 'dot';
    indicator.appendChild(dot);
  }

  wrapper.appendChild(avatar);
  wrapper.appendChild(indicator);
  chatArea.appendChild(wrapper);
  chatArea.scrollTop = chatArea.scrollHeight;
}

function removeTyping() {
  const el = document.getElementById('typingIndicator');
  if (el) el.remove();
}

/* =========================================================
   Chat – Send Message
   ========================================================= */
async function sendMessage() {
  const message = textInput.value.trim();
  if (!message || state.isSending) return;

  // Clear input, disable controls
  textInput.value = '';
  state.isSending = true;
  sendBtn.disabled = true;
  setStatus('பதில் தயாரிக்கிறது…', 'active');

  // Show user message
  appendMessage('user', message);

  // Show typing indicator
  showTyping();

  try {
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, session_id: state.sessionId }),
    });

    if (!response.ok) {
      throw new Error('HTTP ' + response.status);
    }

    const data = await response.json();
    removeTyping();
    appendMessage('nila', data.reply);
    speak(data.reply);
    setStatus('');

  } catch (err) {
    removeTyping();
    const errMsg =
      'மன்னிக்கவும், இப்போது பதில் சொல்ல இயலவில்லை. ' +
      'அருகிலுள்ள அங்கன்வாடி மையம் செல்லவும் அல்லது 1800-111-555 அழைக்கவும்.';
    appendMessage('nila', errMsg);
    speak(errMsg);
    setStatus('இணைப்பு பிழை. மீண்டும் முயற்சிக்கவும்.', 'error');
    console.error('Chat error:', err);
  } finally {
    state.isSending = false;
    sendBtn.disabled = false;
    textInput.focus();
  }
}

/* =========================================================
   Quick Questions
   ========================================================= */
function sendQuick(btn) {
  const question = btn.getAttribute('data-question');
  if (question) {
    textInput.value = question;
    sendMessage();
  }
}

/* =========================================================
   Keyboard Handler
   ========================================================= */
function handleKeyDown(event) {
  if (event.key === 'Enter' && !event.shiftKey) {
    event.preventDefault();
    sendMessage();
  }
}

/* =========================================================
   Init
   ========================================================= */
function init() {
  initTTS();
  initSpeechRecognition();

  // Health check
  fetch('/health')
    .then(r => r.json())
    .then(data => {
      if (data.ai_ready) {
        setStatus('NILA தயார் – Gemini AI இயக்கத்தில் உள்ளது ✓', 'active');
      } else {
        setStatus('NILA தயார் (அடிப்படை பயன்முறை – API key இல்லை)', '');
      }
      setTimeout(() => setStatus(''), 4000);
    })
    .catch(() => setStatus('சேவையகம் இணைக்கப்படவில்லை. புதுப்பிக்கவும்.', 'error'));

  textInput.focus();
}

document.addEventListener('DOMContentLoaded', init);
