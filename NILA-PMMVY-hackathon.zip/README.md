# NILA – PMMVY AI உதவியாளர்

**Tamil-first, voice-first AI assistant for Pradhan Mantri Matru Vandana Yojana (PMMVY)**

[![SDG 5](https://img.shields.io/badge/SDG5-Gender%20Equality-e91e8c)](https://sdgs.un.org/goals/goal5)
[![SDG 4](https://img.shields.io/badge/SDG4-Quality%20Education-c31d1d)](https://sdgs.un.org/goals/goal4)
[![SDG 10](https://img.shields.io/badge/SDG10-Reduced%20Inequalities-dd1367)](https://sdgs.un.org/goals/goal10)

---

## What is NILA?

NILA (நில) is a Tamil-first, voice-first AI assistant designed for first-time rural women users with no English or technical knowledge. It helps them understand and access the **PMMVY** government maternity benefit scheme in simple Tamil, through voice or text.

## Features

- 🎙️ **Tamil voice input** (Browser Speech Recognition, `ta-IN`)
- 🔊 **Tamil voice output** (Browser Speech Synthesis, `ta-IN`)
- 🤖 **AI-powered answers** using Google Gemini with strict guardrails
- 📋 **Controlled PMMVY knowledge base** – no hallucinated government facts
- ⚠️ **Safety guardrails** – never asks for Aadhaar, OTP, PIN, or bank credentials
- 📱 **Mobile-first UI** in Tamil
- 🏛️ **Official portal link** – https://pmmvy.wcd.gov.in
- 🌐 **Scalable architecture** – add new schemes or Indian languages easily

## Tech Stack

| Layer    | Technology                        |
|----------|-----------------------------------|
| Backend  | Python, FastAPI, Uvicorn          |
| AI       | Google Gemini API (gemini-1.5-flash) |
| Frontend | HTML5, CSS3, Vanilla JavaScript   |
| Voice    | Web Speech API (ta-IN)            |

## Quick Start

### 1. Clone and enter the directory
```bash
cd NILA-PMMVY
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Set up environment
```bash
copy .env.example .env
# Edit .env and add your GEMINI_API_KEY
```

### 4. Run the server
```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

### 5. Open in browser
```
http://localhost:8000
```

## Project Structure

```
NILA-PMMVY/
├── main.py              # FastAPI application + Gemini integration
├── requirements.txt     # Python dependencies
├── .env.example         # Environment variable template
├── .gitignore
├── README.md
├── data/
│   ├── __init__.py
│   └── pmmvy.py         # Controlled PMMVY knowledge base
└── static/
    ├── index.html       # Tamil UI
    ├── style.css        # Mobile-first styles
    └── app.js           # Speech + chat logic
```

## API Endpoints

| Method | Path         | Description                   |
|--------|--------------|-------------------------------|
| GET    | `/`          | Serve the UI                  |
| GET    | `/health`    | Health check + AI status      |
| GET    | `/api/scheme`| PMMVY scheme summary (JSON)   |
| POST   | `/api/chat`  | Chat with NILA (Tamil AI)     |

## Safety & Ethics

- ❌ Never asks for Aadhaar, OTP, PIN, passwords, or bank credentials
- ❌ Never claims definite eligibility
- ✅ Always refers to official government portal and Anganwadi centres
- ✅ Answers only from controlled PMMVY knowledge base
- ✅ Prominent safety banner visible at all times

## Adding a New Scheme (Scalability)

1. Create `data/<scheme_name>.py` with a `get_context_for_ai()` function
2. Add a new route in `main.py` with a `scheme_id` parameter
3. The frontend can add a scheme selector

## Adding a New Language

1. Change `SpeechRecognition.lang` and `SpeechSynthesisUtterance.lang` in `app.js`
2. Update system prompt language in `main.py`
3. Update knowledge base text in `data/pmmvy.py`

## Official PMMVY Resources

- Portal: https://pmmvy.wcd.gov.in
- Ministry: https://wcd.nic.in/schemes/pradhan-mantri-matru-vandana-yojana
- Helpline: **1800-111-555** (Toll-free)

---

*Hackathon MVP — Built for SDG 5, SDG 4, SDG 10*
